# GSDA - Lesson 12 - HTML, CSS - Multi-block Registration Form

A Pen created on CodePen.io. Original URL: [https://codepen.io/agalib/pen/vYjjKzJ](https://codepen.io/agalib/pen/vYjjKzJ).

